
from django.contrib import admin
from .models import HealthRecord, Tag

admin.site.register(HealthRecord)
admin.site.register(Tag) 
